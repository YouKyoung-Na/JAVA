package derived;
import base.Shape;

public class Circle extends Shape {  // Circle 클래스 Shape을 상속 받음 
	public void draw() {System.out.println("Circle");}
}
