package base;

public class Shape {  // Shape 클래스 문제 제시됨 
	public void draw() {System.out.println("Shape");}
}
